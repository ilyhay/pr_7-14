package com.example.pr_10_clock;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ShowItems extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
    }
}